import { Link } from "react-router-dom";

export default function ThankYouPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-orange-500 px-6 text-white">
      <h1 className="text-4xl font-bold">Thank You! Registration Complete</h1>
      <Link className="text-lg underline underline-offset-4" to="/">
        Back to Home
      </Link>
    </main>
  );
}