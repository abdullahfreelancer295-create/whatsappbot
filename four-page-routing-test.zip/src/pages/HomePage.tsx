import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-blue-500 px-6 text-white">
      <h1 className="text-4xl font-bold">Welcome Home</h1>
      <Link className="text-lg underline underline-offset-4" to="/login">
        Go to Login
      </Link>
      <Link className="text-lg underline underline-offset-4" to="/signup">
        Go to Signup
      </Link>
      <Link className="text-lg underline underline-offset-4" to="/">
        Back to Home
      </Link>
    </main>
  );
}