import { Link } from "react-router-dom";

export default function LoginPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-5 bg-green-500 px-6 text-white">
      <h1 className="text-4xl font-bold">Login</h1>
      <form className="flex w-full max-w-sm flex-col gap-3">
        <input
          type="email"
          placeholder="Email"
          className="rounded border border-white/60 bg-white px-3 py-2 text-black outline-none"
          required
        />
        <input
          type="password"
          placeholder="Password"
          className="rounded border border-white/60 bg-white px-3 py-2 text-black outline-none"
          required
        />
        <button
          type="submit"
          className="rounded bg-black px-4 py-2 font-semibold text-white transition hover:bg-black/85"
        >
          Login
        </button>
      </form>
      <Link className="text-lg underline underline-offset-4" to="/">
        Back to Home
      </Link>
    </main>
  );
}